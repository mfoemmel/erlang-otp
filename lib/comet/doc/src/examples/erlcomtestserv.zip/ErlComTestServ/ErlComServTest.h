// ErlComServTest.h: Definition of the CErlComServTst class
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ERLCOMSERVTEST_H__5FFFAC7F_E087_11D3_AC85_00C04F9DA8C8__INCLUDED_)
#define AFX_ERLCOMSERVTEST_H__5FFFAC7F_E087_11D3_AC85_00C04F9DA8C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CErlComServTst

class CErlComServTst : 
	public IDispatchImpl<IErlComServTst, &IID_IErlComServTst, &LIBID_ERLCOMTESTSERVLib>, 
	public ISupportErrorInfo,
	public CComObjectRoot,
	public CComCoClass<CErlComServTst,&CLSID_ErlComServTst>
{
public:
	CErlComServTst() {}
BEGIN_COM_MAP(CErlComServTst)
	COM_INTERFACE_ENTRY(IDispatch)
	COM_INTERFACE_ENTRY(IErlComServTst)
	COM_INTERFACE_ENTRY(ISupportErrorInfo)
END_COM_MAP()
//DECLARE_NOT_AGGREGATABLE(CErlComServTst) 
// Remove the comment from the line above if you don't want your object to 
// support aggregation. 

DECLARE_REGISTRY_RESOURCEID(IDR_ErlComServTst)
// ISupportsErrorInfo
	STDMETHOD(InterfaceSupportsErrorInfo)(REFIID riid);

// IErlComServTst
public:
	STDMETHOD(Delay)(/*[in]*/ long mSecs);
	STDMETHOD(R8Add)(/*[in]*/ double a, /*[in]*/ double b, /*[out]*/ double* c);
	STDMETHOD(DaysBetween)(/*[in]*/ DATE date1, /*[in]*/ DATE date2, /*[out]*/ double* daysBetween);
	STDMETHOD(ReverseString)(/*[in]*/ BSTR inStr, /*[out]*/ BSTR* outStr);
	STDMETHOD(GetCurrentDate)(/*[out]*/ DATE* currentDate);
	STDMETHOD(I4Add)(/*[in]*/ long a, /*[in]*/ long b, /*[out]*/ long* c);
	STDMETHOD(SumArray)(/*[in]*/ VARIANT* numbers, /*[out]*/ double* sum);
};

#endif // !defined(AFX_ERLCOMSERVTEST_H__5FFFAC7F_E087_11D3_AC85_00C04F9DA8C8__INCLUDED_)
