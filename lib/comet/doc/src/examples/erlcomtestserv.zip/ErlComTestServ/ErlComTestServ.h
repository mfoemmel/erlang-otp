
#pragma warning( disable: 4049 )  /* more than 64k source lines */

/* this ALWAYS GENERATED file contains the definitions for the interfaces */


 /* File created by MIDL compiler version 5.03.0280 */
/* at Tue Apr 04 11:07:42 2000
 */
/* Compiler settings for C:\JC\ErlComTestServ\ErlComTestServ\ErlComTestServ.idl:
    Oicf (OptLev=i2), W1, Zp8, env=Win32 (32b run), ms_ext, c_ext
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )


/* verify that the <rpcndr.h> version is high enough to compile this file*/
#ifndef __REQUIRED_RPCNDR_H_VERSION__
#define __REQUIRED_RPCNDR_H_VERSION__ 440
#endif

#include "rpc.h"
#include "rpcndr.h"

#ifndef __RPCNDR_H_VERSION__
#error this stub requires an updated version of <rpcndr.h>
#endif // __RPCNDR_H_VERSION__

#ifndef COM_NO_WINDOWS_H
#include "windows.h"
#include "ole2.h"
#endif /*COM_NO_WINDOWS_H*/

#ifndef __ErlComTestServ_h__
#define __ErlComTestServ_h__

/* Forward Declarations */ 

#ifndef __IErlComServTst_FWD_DEFINED__
#define __IErlComServTst_FWD_DEFINED__
typedef interface IErlComServTst IErlComServTst;
#endif 	/* __IErlComServTst_FWD_DEFINED__ */


#ifndef __ErlComServTst_FWD_DEFINED__
#define __ErlComServTst_FWD_DEFINED__

#ifdef __cplusplus
typedef class ErlComServTst ErlComServTst;
#else
typedef struct ErlComServTst ErlComServTst;
#endif /* __cplusplus */

#endif 	/* __ErlComServTst_FWD_DEFINED__ */


/* header files for imported files */
#include "oaidl.h"
#include "ocidl.h"

#ifdef __cplusplus
extern "C"{
#endif 

void __RPC_FAR * __RPC_USER MIDL_user_allocate(size_t);
void __RPC_USER MIDL_user_free( void __RPC_FAR * ); 

#ifndef __IErlComServTst_INTERFACE_DEFINED__
#define __IErlComServTst_INTERFACE_DEFINED__

/* interface IErlComServTst */
/* [unique][helpstring][dual][uuid][object] */ 


EXTERN_C const IID IID_IErlComServTst;

#if defined(__cplusplus) && !defined(CINTERFACE)
    
    MIDL_INTERFACE("5FFFAC7D-E087-11D3-AC85-00C04F9DA8C8")
    IErlComServTst : public IDispatch
    {
    public:
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE I4Add( 
            /* [in] */ long a,
            /* [in] */ long b,
            /* [out] */ long __RPC_FAR *c) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE GetCurrentDate( 
            /* [out] */ DATE __RPC_FAR *currentDate) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE ReverseString( 
            /* [in] */ BSTR inStr,
            /* [out] */ BSTR __RPC_FAR *outStr) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE DaysBetween( 
            /* [in] */ DATE date1,
            /* [in] */ DATE date2,
            /* [out] */ double __RPC_FAR *daysBetween) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE R8Add( 
            /* [in] */ double a,
            /* [in] */ double b,
            /* [out] */ double __RPC_FAR *c) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE SumArray( 
            /* [in] */ VARIANT __RPC_FAR *numbers,
            /* [out] */ double __RPC_FAR *sum) = 0;
        
        virtual /* [helpstring][id] */ HRESULT STDMETHODCALLTYPE Delay( 
            /* [in] */ long mSecs) = 0;
        
    };
    
#else 	/* C style interface */

    typedef struct IErlComServTstVtbl
    {
        BEGIN_INTERFACE
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *QueryInterface )( 
            IErlComServTst __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [iid_is][out] */ void __RPC_FAR *__RPC_FAR *ppvObject);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *AddRef )( 
            IErlComServTst __RPC_FAR * This);
        
        ULONG ( STDMETHODCALLTYPE __RPC_FAR *Release )( 
            IErlComServTst __RPC_FAR * This);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfoCount )( 
            IErlComServTst __RPC_FAR * This,
            /* [out] */ UINT __RPC_FAR *pctinfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetTypeInfo )( 
            IErlComServTst __RPC_FAR * This,
            /* [in] */ UINT iTInfo,
            /* [in] */ LCID lcid,
            /* [out] */ ITypeInfo __RPC_FAR *__RPC_FAR *ppTInfo);
        
        HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetIDsOfNames )( 
            IErlComServTst __RPC_FAR * This,
            /* [in] */ REFIID riid,
            /* [size_is][in] */ LPOLESTR __RPC_FAR *rgszNames,
            /* [in] */ UINT cNames,
            /* [in] */ LCID lcid,
            /* [size_is][out] */ DISPID __RPC_FAR *rgDispId);
        
        /* [local] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Invoke )( 
            IErlComServTst __RPC_FAR * This,
            /* [in] */ DISPID dispIdMember,
            /* [in] */ REFIID riid,
            /* [in] */ LCID lcid,
            /* [in] */ WORD wFlags,
            /* [out][in] */ DISPPARAMS __RPC_FAR *pDispParams,
            /* [out] */ VARIANT __RPC_FAR *pVarResult,
            /* [out] */ EXCEPINFO __RPC_FAR *pExcepInfo,
            /* [out] */ UINT __RPC_FAR *puArgErr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *I4Add )( 
            IErlComServTst __RPC_FAR * This,
            /* [in] */ long a,
            /* [in] */ long b,
            /* [out] */ long __RPC_FAR *c);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *GetCurrentDate )( 
            IErlComServTst __RPC_FAR * This,
            /* [out] */ DATE __RPC_FAR *currentDate);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *ReverseString )( 
            IErlComServTst __RPC_FAR * This,
            /* [in] */ BSTR inStr,
            /* [out] */ BSTR __RPC_FAR *outStr);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *DaysBetween )( 
            IErlComServTst __RPC_FAR * This,
            /* [in] */ DATE date1,
            /* [in] */ DATE date2,
            /* [out] */ double __RPC_FAR *daysBetween);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *R8Add )( 
            IErlComServTst __RPC_FAR * This,
            /* [in] */ double a,
            /* [in] */ double b,
            /* [out] */ double __RPC_FAR *c);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *SumArray )( 
            IErlComServTst __RPC_FAR * This,
            /* [in] */ VARIANT __RPC_FAR *numbers,
            /* [out] */ double __RPC_FAR *sum);
        
        /* [helpstring][id] */ HRESULT ( STDMETHODCALLTYPE __RPC_FAR *Delay )( 
            IErlComServTst __RPC_FAR * This,
            /* [in] */ long mSecs);
        
        END_INTERFACE
    } IErlComServTstVtbl;

    interface IErlComServTst
    {
        CONST_VTBL struct IErlComServTstVtbl __RPC_FAR *lpVtbl;
    };

    

#ifdef COBJMACROS


#define IErlComServTst_QueryInterface(This,riid,ppvObject)	\
    (This)->lpVtbl -> QueryInterface(This,riid,ppvObject)

#define IErlComServTst_AddRef(This)	\
    (This)->lpVtbl -> AddRef(This)

#define IErlComServTst_Release(This)	\
    (This)->lpVtbl -> Release(This)


#define IErlComServTst_GetTypeInfoCount(This,pctinfo)	\
    (This)->lpVtbl -> GetTypeInfoCount(This,pctinfo)

#define IErlComServTst_GetTypeInfo(This,iTInfo,lcid,ppTInfo)	\
    (This)->lpVtbl -> GetTypeInfo(This,iTInfo,lcid,ppTInfo)

#define IErlComServTst_GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)	\
    (This)->lpVtbl -> GetIDsOfNames(This,riid,rgszNames,cNames,lcid,rgDispId)

#define IErlComServTst_Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)	\
    (This)->lpVtbl -> Invoke(This,dispIdMember,riid,lcid,wFlags,pDispParams,pVarResult,pExcepInfo,puArgErr)


#define IErlComServTst_I4Add(This,a,b,c)	\
    (This)->lpVtbl -> I4Add(This,a,b,c)

#define IErlComServTst_GetCurrentDate(This,currentDate)	\
    (This)->lpVtbl -> GetCurrentDate(This,currentDate)

#define IErlComServTst_ReverseString(This,inStr,outStr)	\
    (This)->lpVtbl -> ReverseString(This,inStr,outStr)

#define IErlComServTst_DaysBetween(This,date1,date2,daysBetween)	\
    (This)->lpVtbl -> DaysBetween(This,date1,date2,daysBetween)

#define IErlComServTst_R8Add(This,a,b,c)	\
    (This)->lpVtbl -> R8Add(This,a,b,c)

#define IErlComServTst_SumArray(This,numbers,sum)	\
    (This)->lpVtbl -> SumArray(This,numbers,sum)

#define IErlComServTst_Delay(This,mSecs)	\
    (This)->lpVtbl -> Delay(This,mSecs)

#endif /* COBJMACROS */


#endif 	/* C style interface */



/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IErlComServTst_I4Add_Proxy( 
    IErlComServTst __RPC_FAR * This,
    /* [in] */ long a,
    /* [in] */ long b,
    /* [out] */ long __RPC_FAR *c);


void __RPC_STUB IErlComServTst_I4Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IErlComServTst_GetCurrentDate_Proxy( 
    IErlComServTst __RPC_FAR * This,
    /* [out] */ DATE __RPC_FAR *currentDate);


void __RPC_STUB IErlComServTst_GetCurrentDate_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IErlComServTst_ReverseString_Proxy( 
    IErlComServTst __RPC_FAR * This,
    /* [in] */ BSTR inStr,
    /* [out] */ BSTR __RPC_FAR *outStr);


void __RPC_STUB IErlComServTst_ReverseString_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IErlComServTst_DaysBetween_Proxy( 
    IErlComServTst __RPC_FAR * This,
    /* [in] */ DATE date1,
    /* [in] */ DATE date2,
    /* [out] */ double __RPC_FAR *daysBetween);


void __RPC_STUB IErlComServTst_DaysBetween_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IErlComServTst_R8Add_Proxy( 
    IErlComServTst __RPC_FAR * This,
    /* [in] */ double a,
    /* [in] */ double b,
    /* [out] */ double __RPC_FAR *c);


void __RPC_STUB IErlComServTst_R8Add_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IErlComServTst_SumArray_Proxy( 
    IErlComServTst __RPC_FAR * This,
    /* [in] */ VARIANT __RPC_FAR *numbers,
    /* [out] */ double __RPC_FAR *sum);


void __RPC_STUB IErlComServTst_SumArray_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);


/* [helpstring][id] */ HRESULT STDMETHODCALLTYPE IErlComServTst_Delay_Proxy( 
    IErlComServTst __RPC_FAR * This,
    /* [in] */ long mSecs);


void __RPC_STUB IErlComServTst_Delay_Stub(
    IRpcStubBuffer *This,
    IRpcChannelBuffer *_pRpcChannelBuffer,
    PRPC_MESSAGE _pRpcMessage,
    DWORD *_pdwStubPhase);



#endif 	/* __IErlComServTst_INTERFACE_DEFINED__ */



#ifndef __ERLCOMTESTSERVLib_LIBRARY_DEFINED__
#define __ERLCOMTESTSERVLib_LIBRARY_DEFINED__

/* library ERLCOMTESTSERVLib */
/* [helpstring][version][uuid] */ 


EXTERN_C const IID LIBID_ERLCOMTESTSERVLib;

EXTERN_C const CLSID CLSID_ErlComServTst;

#ifdef __cplusplus

class DECLSPEC_UUID("5FFFAC7E-E087-11D3-AC85-00C04F9DA8C8")
ErlComServTst;
#endif
#endif /* __ERLCOMTESTSERVLib_LIBRARY_DEFINED__ */

/* Additional Prototypes for ALL interfaces */

unsigned long             __RPC_USER  BSTR_UserSize(     unsigned long __RPC_FAR *, unsigned long            , BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  BSTR_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, BSTR __RPC_FAR * ); 
void                      __RPC_USER  BSTR_UserFree(     unsigned long __RPC_FAR *, BSTR __RPC_FAR * ); 

unsigned long             __RPC_USER  VARIANT_UserSize(     unsigned long __RPC_FAR *, unsigned long            , VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserMarshal(  unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
unsigned char __RPC_FAR * __RPC_USER  VARIANT_UserUnmarshal(unsigned long __RPC_FAR *, unsigned char __RPC_FAR *, VARIANT __RPC_FAR * ); 
void                      __RPC_USER  VARIANT_UserFree(     unsigned long __RPC_FAR *, VARIANT __RPC_FAR * ); 

/* end of Additional Prototypes */

#ifdef __cplusplus
}
#endif

#endif


